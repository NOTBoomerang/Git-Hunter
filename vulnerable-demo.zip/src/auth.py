import hashlib
import os

# VULNERABILITY: Weak password hashing
def hash_password(password):
    return hashlib.md5(password.encode()).hexdigest()

# VULNERABILITY: Hardcoded secrets  
def get_secret_key():
    return "my-secret-key-123"

# VULNERABILITY: Command injection
def backup_user_data(username):
    os.system(f"tar -czf /tmp/{username}_backup.tar.gz /data/{username}")
    
# VULNERABILITY: Path traversal
def read_user_file(username, filename):
    with open(f"/data/{username}/{filename}", 'r') as f:
        return f.read()