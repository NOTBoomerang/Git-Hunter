const express = require('express');
const app = express();

// VULNERABILITY: SQL Injection
app.get('/user/:id', (req, res) => {
  const query = `SELECT * FROM users WHERE id = ${req.params.id}`;
  // This allows SQL injection attacks
  db.query(query, (err, results) => {
    res.json(results);
  });
});

// VULNERABILITY: Hardcoded credentials
const admin_password = "admin123";
const api_key = "sk-1234567890abcdef";

app.listen(3000);